﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblAPP = new System.Windows.Forms.Label();
            this.lblA = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.lblDev = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            this.txtValA = new System.Windows.Forms.TextBox();
            this.txtValB = new System.Windows.Forms.TextBox();
            this.txtValC = new System.Windows.Forms.TextBox();
            this.btnExe = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.btnClean = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAPP
            // 
            this.lblAPP.AutoSize = true;
            this.lblAPP.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblAPP.Font = new System.Drawing.Font("Microsoft YaHei", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAPP.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblAPP.Location = new System.Drawing.Point(243, 9);
            this.lblAPP.Name = "lblAPP";
            this.lblAPP.Size = new System.Drawing.Size(323, 58);
            this.lblAPP.TabIndex = 0;
            this.lblAPP.Text = "TRIANGULOS";
            this.lblAPP.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblA.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblA.Location = new System.Drawing.Point(179, 114);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(95, 20);
            this.lblA.TabIndex = 1;
            this.lblA.Text = "Valor lado A";
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblB.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblB.Location = new System.Drawing.Point(179, 148);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(95, 20);
            this.lblB.TabIndex = 2;
            this.lblB.Text = "Valor lado B";
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblC.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblC.Location = new System.Drawing.Point(179, 181);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(95, 20);
            this.lblC.TabIndex = 3;
            this.lblC.Text = "Valor lado C";
            // 
            // lblDev
            // 
            this.lblDev.AutoSize = true;
            this.lblDev.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblDev.ForeColor = System.Drawing.Color.Snow;
            this.lblDev.Location = new System.Drawing.Point(42, 381);
            this.lblDev.Name = "lblDev";
            this.lblDev.Size = new System.Drawing.Size(231, 20);
            this.lblDev.TabIndex = 6;
            this.lblDev.Text = "Desenvolvido por Gustavo Berti";
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblVersion.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblVersion.Location = new System.Drawing.Point(42, 406);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(86, 20);
            this.lblVersion.TabIndex = 7;
            this.lblVersion.Text = "Versão 1.0";
            // 
            // txtValA
            // 
            this.txtValA.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtValA.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtValA.Location = new System.Drawing.Point(304, 108);
            this.txtValA.Name = "txtValA";
            this.txtValA.Size = new System.Drawing.Size(100, 26);
            this.txtValA.TabIndex = 8;
            // 
            // txtValB
            // 
            this.txtValB.Location = new System.Drawing.Point(304, 145);
            this.txtValB.Name = "txtValB";
            this.txtValB.Size = new System.Drawing.Size(100, 26);
            this.txtValB.TabIndex = 9;
            // 
            // txtValC
            // 
            this.txtValC.Location = new System.Drawing.Point(304, 181);
            this.txtValC.Name = "txtValC";
            this.txtValC.Size = new System.Drawing.Size(100, 26);
            this.txtValC.TabIndex = 10;
            // 
            // btnExe
            // 
            this.btnExe.Location = new System.Drawing.Point(316, 260);
            this.btnExe.Name = "btnExe";
            this.btnExe.Size = new System.Drawing.Size(97, 41);
            this.btnExe.TabIndex = 11;
            this.btnExe.Text = "Executar";
            this.btnExe.UseVisualStyleBackColor = true;
            this.btnExe.Click += new System.EventHandler(this.btnExe_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(680, 381);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(88, 45);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "SAIR";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblResultado.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblResultado.Location = new System.Drawing.Point(604, 108);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(82, 20);
            this.lblResultado.TabIndex = 13;
            this.lblResultado.Text = "Resultado";
            // 
            // txtResultado
            // 
            this.txtResultado.Enabled = false;
            this.txtResultado.Location = new System.Drawing.Point(543, 131);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(196, 26);
            this.txtResultado.TabIndex = 14;
            // 
            // btnClean
            // 
            this.btnClean.Location = new System.Drawing.Point(434, 260);
            this.btnClean.Name = "btnClean";
            this.btnClean.Size = new System.Drawing.Size(99, 41);
            this.btnClean.TabIndex = 15;
            this.btnClean.Text = "Limpar";
            this.btnClean.UseVisualStyleBackColor = true;
            this.btnClean.Click += new System.EventHandler(this.btnClean_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClean);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnExe);
            this.Controls.Add(this.txtValC);
            this.Controls.Add(this.txtValB);
            this.Controls.Add(this.txtValA);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.lblDev);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.lblAPP);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAPP;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.Label lblDev;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.TextBox txtValA;
        private System.Windows.Forms.TextBox txtValB;
        private System.Windows.Forms.TextBox txtValC;
        private System.Windows.Forms.Button btnExe;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button btnClean;
    }
}

