﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnExe_Click(object sender, EventArgs e)
        {

            double A, B, C;

            if (double.TryParse(txtValA.Text, out A) &&
                double.TryParse(txtValB.Text, out B) &&
                double.TryParse(txtValC.Text, out C))
            {

                if (Math.Abs(B - C) < (A) && (A) < (B + C) &&
                    Math.Abs(A - C) < (B) && (B) < (A + C) &&
                    Math.Abs(A - B) < (C) && (C) < (A + B))
                {

                    MessageBox.Show("É um triângulo!!!!");

                                    
                   
                    if (A == B && B == C)
                        txtResultado.Text = "Equilátero";

                    else if (A == B || A == C || B == C)
                        txtResultado.Text = "Isóceles";

                    else txtResultado.Text = "Triângulo Escaleno";

                                       
                }
                else txtResultado.Text = "Não forma um triângulo!";

            }
            else MessageBox.Show("Valores inválidos!");
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            txtValA.Clear();
            txtValB.Clear();
            txtValC.Clear();
            txtResultado.Clear();
            txtValA.Focus();
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
