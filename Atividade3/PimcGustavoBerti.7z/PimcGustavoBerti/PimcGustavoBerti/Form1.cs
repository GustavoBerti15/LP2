﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimcGustavoBerti
{
    public partial class Form1 : Form


    {
        double Altura, Peso, IMC;

        private object altura;
        private object peso;


        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtIMC.Clear();
            txtClass.Clear();
            txtPeso.Focus();
        }

        private void txtClass_Validated(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out double Peso) || Peso <= 0)
            {

                MessageBox.Show("Informe o valor em KG, entrada inválida");
                txtPeso.Focus();
            }

            else if (!double.TryParse(txtAltura.Text, out double Altura) || Altura <= 0)
            {

                MessageBox.Show("Informe o valor em CM, entrada inválida");
                txtAltura.Focus();
            }
            else
            {

                double IMC = Peso / (Altura * Altura);
                MessageBox.Show("Seu IMC é: " + IMC.ToString("F2"));
                IMC=Math.Round(IMC,1);
                txtIMC.Text = IMC.ToString("F2");
                if (IMC < 18.5)
                    txtClass.Text = "Magreza";
                else if (IMC < 25)
                    txtClass.Text = "Normal";
                else if (IMC < 30)
                    txtClass.Text = "Sobrepeso";
                else if (IMC < 40)
                    txtClass.Text = "Obesidade";
                if (IMC >= 40)
                    txtClass.Text = "Obesidade Grave";
            }




        }


    }
}

