﻿namespace PCalcGustavoBerti
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblBemVindo = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            this.lblDev = new System.Windows.Forms.Label();
            this.txtboxnum2 = new System.Windows.Forms.TextBox();
            this.txtboxnum1 = new System.Windows.Forms.TextBox();
            this.txtboxResult = new System.Windows.Forms.TextBox();
            this.btnClean = new System.Windows.Forms.Button();
            this.bntExit = new System.Windows.Forms.Button();
            this.btnADD = new System.Windows.Forms.Button();
            this.btnSub = new System.Windows.Forms.Button();
            this.btnMult = new System.Windows.Forms.Button();
            this.btnDiv = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(128, 68);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(93, 20);
            this.lblNum1.TabIndex = 0;
            this.lblNum1.Text = "NÚMERO 1";
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Location = new System.Drawing.Point(128, 104);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(93, 20);
            this.lblNum2.TabIndex = 1;
            this.lblNum2.Text = "NÚMERO 2";
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(500, 216);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(108, 20);
            this.lblResult.TabIndex = 2;
            this.lblResult.Text = "RESULTADO";
            // 
            // lblBemVindo
            // 
            this.lblBemVindo.AutoSize = true;
            this.lblBemVindo.Location = new System.Drawing.Point(469, 9);
            this.lblBemVindo.Name = "lblBemVindo";
            this.lblBemVindo.Size = new System.Drawing.Size(202, 20);
            this.lblBemVindo.TabIndex = 3;
            this.lblBemVindo.Text = "Bem Vindo a SMARTCALC";
            this.lblBemVindo.Click += new System.EventHandler(this.lblBemVindo_Click);
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Location = new System.Drawing.Point(31, 386);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(86, 20);
            this.lblVersion.TabIndex = 4;
            this.lblVersion.Text = "Versão 1.0";
            // 
            // lblDev
            // 
            this.lblDev.AutoSize = true;
            this.lblDev.Location = new System.Drawing.Point(31, 406);
            this.lblDev.Name = "lblDev";
            this.lblDev.Size = new System.Drawing.Size(231, 20);
            this.lblDev.TabIndex = 5;
            this.lblDev.Text = "Desenvolvido por Gustavo Berti";
            // 
            // txtboxnum2
            // 
            this.txtboxnum2.Location = new System.Drawing.Point(245, 104);
            this.txtboxnum2.Name = "txtboxnum2";
            this.txtboxnum2.Size = new System.Drawing.Size(224, 26);
            this.txtboxnum2.TabIndex = 1;
            this.txtboxnum2.Validated += new System.EventHandler(this.txtboxnum2_Validated);
            // 
            // txtboxnum1
            // 
            this.txtboxnum1.Location = new System.Drawing.Point(245, 68);
            this.txtboxnum1.Name = "txtboxnum1";
            this.txtboxnum1.Size = new System.Drawing.Size(224, 26);
            this.txtboxnum1.TabIndex = 0;
            this.txtboxnum1.Validated += new System.EventHandler(this.txtboxnum1_Validated);
            // 
            // txtboxResult
            // 
            this.txtboxResult.Location = new System.Drawing.Point(297, 250);
            this.txtboxResult.Name = "txtboxResult";
            this.txtboxResult.Size = new System.Drawing.Size(490, 26);
            this.txtboxResult.TabIndex = 8;
            this.txtboxResult.TextChanged += new System.EventHandler(this.txtboxResult_TextChanged);
            // 
            // btnClean
            // 
            this.btnClean.Location = new System.Drawing.Point(922, 68);
            this.btnClean.Name = "btnClean";
            this.btnClean.Size = new System.Drawing.Size(99, 35);
            this.btnClean.TabIndex = 9;
            this.btnClean.Text = "LIMPAR";
            this.btnClean.UseVisualStyleBackColor = true;
            this.btnClean.Click += new System.EventHandler(this.btnClean_Click);
            // 
            // bntExit
            // 
            this.bntExit.Location = new System.Drawing.Point(922, 122);
            this.bntExit.Name = "bntExit";
            this.bntExit.Size = new System.Drawing.Size(99, 31);
            this.bntExit.TabIndex = 10;
            this.bntExit.Text = "SAIR";
            this.bntExit.UseVisualStyleBackColor = true;
            this.bntExit.Click += new System.EventHandler(this.bntExit_Click);
            // 
            // btnADD
            // 
            this.btnADD.Location = new System.Drawing.Point(277, 301);
            this.btnADD.Name = "btnADD";
            this.btnADD.Size = new System.Drawing.Size(93, 66);
            this.btnADD.TabIndex = 11;
            this.btnADD.Text = "SOMAR";
            this.btnADD.UseVisualStyleBackColor = true;
            this.btnADD.Click += new System.EventHandler(this.btnADD_Click);
            // 
            // btnSub
            // 
            this.btnSub.Location = new System.Drawing.Point(393, 301);
            this.btnSub.Name = "btnSub";
            this.btnSub.Size = new System.Drawing.Size(102, 66);
            this.btnSub.TabIndex = 12;
            this.btnSub.Text = "SUBTRAIR";
            this.btnSub.UseVisualStyleBackColor = true;
            this.btnSub.Click += new System.EventHandler(this.btnSub_Click);
            // 
            // btnMult
            // 
            this.btnMult.Location = new System.Drawing.Point(532, 301);
            this.btnMult.Name = "btnMult";
            this.btnMult.Size = new System.Drawing.Size(139, 66);
            this.btnMult.TabIndex = 13;
            this.btnMult.Text = "MULTIPLICAR";
            this.btnMult.UseVisualStyleBackColor = true;
            this.btnMult.Click += new System.EventHandler(this.btnMult_Click);
            // 
            // btnDiv
            // 
            this.btnDiv.Location = new System.Drawing.Point(707, 301);
            this.btnDiv.Name = "btnDiv";
            this.btnDiv.Size = new System.Drawing.Size(93, 66);
            this.btnDiv.TabIndex = 14;
            this.btnDiv.Text = "DIVIDIR";
            this.btnDiv.UseVisualStyleBackColor = true;
            this.btnDiv.Click += new System.EventHandler(this.button6_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 450);
            this.Controls.Add(this.btnDiv);
            this.Controls.Add(this.btnMult);
            this.Controls.Add(this.btnSub);
            this.Controls.Add(this.btnADD);
            this.Controls.Add(this.bntExit);
            this.Controls.Add(this.btnClean);
            this.Controls.Add(this.txtboxResult);
            this.Controls.Add(this.txtboxnum1);
            this.Controls.Add(this.txtboxnum2);
            this.Controls.Add(this.lblDev);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.lblBemVindo);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.lblNum1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblBemVindo;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Label lblDev;
        private System.Windows.Forms.TextBox txtboxnum2;
        private System.Windows.Forms.TextBox txtboxnum1;
        private System.Windows.Forms.TextBox txtboxResult;
        private System.Windows.Forms.Button btnClean;
        private System.Windows.Forms.Button bntExit;
        private System.Windows.Forms.Button btnADD;
        private System.Windows.Forms.Button btnSub;
        private System.Windows.Forms.Button btnMult;
        private System.Windows.Forms.Button btnDiv;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
    }
}

