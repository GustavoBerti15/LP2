﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalcGustavoBerti
{
    public partial class Form1 : Form
    {
        double num1, num2, resultado;


        public Form1()
        {
            InitializeComponent();
        }

        private void lblBemVindo_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                double num1 = double.Parse(txtboxnum1.Text);
                double num2 = double.Parse(txtboxnum2.Text);

                if (num2 == 0)
                {

                    MessageBox.Show("Não é possível dividir por zero!");
                }
                else
                {

                    double resultado = num1 / num2;
                    txtboxResult.Text = resultado.ToString();
                }
            }
            catch
            {
                MessageBox.Show("Digite apenas números válidos!");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtboxnum2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtboxnum2, " ");
                num2 = Convert.ToDouble(txtboxnum2.Text);

            }
            catch
            {
                errorProvider2.SetError(txtboxnum2, "Número 2 é inválido");
                txtboxnum2.Focus();
            }

        }

        private void txtboxResult_TextChanged(object sender, EventArgs e)
        { }
        private void txtboxnum1_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtboxnum1, " ");
                num1 = Convert.ToDouble(txtboxnum1.Text);

            }
            catch
            {
                errorProvider1.SetError(txtboxnum1, "Número 1 é inválido");
                txtboxnum1.Focus();

            }
        }
        private void btnSub_Click(object sender, EventArgs e)
        {
            try
            {
                double num1 = double.Parse(txtboxnum1.Text);
                double num2 = double.Parse(txtboxnum2.Text);
                double resultado = num1 - num2;
                txtboxResult.Text = resultado.ToString();
            }
            catch
            {
                MessageBox.Show("Digite apenas números válidos!");
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            try
            {
                double num1 = double.Parse(txtboxnum1.Text);
                double num2 = double.Parse(txtboxnum2.Text);
                double resultado = num1 * num2;
                txtboxResult.Text = resultado.ToString();
            }
            catch
            {
                MessageBox.Show("Digite apenas números válidos!");
            }
        }

        private void bntExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja mesmo sair?",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) ==
                DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            txtboxnum1.Clear();
            txtboxnum2.Clear();
            txtboxResult.Clear();
            txtboxnum1.Focus();

        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            try
            {
                double num1 = double.Parse(txtboxnum1.Text);
                double num2 = double.Parse(txtboxnum2.Text);
                double resultado = num1 + num2;
                txtboxResult.Text = resultado.ToString();
            }
            catch
            {
                MessageBox.Show("Digite apenas números válidos!");
            }
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {

        }
    }
}
