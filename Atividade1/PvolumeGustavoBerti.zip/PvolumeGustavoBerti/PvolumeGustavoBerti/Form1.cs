﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PvolumeGustavoBerti
{
    public partial class Form1 : Form
    {

        double raio, altura, volume; /*golbais */

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura informado inválido!");


            }
            else
            {
                if (altura <= 0)
                {
                    MessageBox.Show("A altura deve ser maior que 0 (ZERO)");
                }

            }

        }

        private void lblBemvindo_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || raio <= 0)
            {
                MessageBox.Show("O raio é inválido");
                txtRaio.Focus();
            }

            else if (!Double.TryParse(txtAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("A altura informada é inválida");
                txtAltura.Focus();
            }

            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }





        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = string.Empty;
            txtVolume.Clear();
            txtAltura.Clear();
            txtRaio.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio) || raio <= 0)
            {
                MessageBox.Show("Raio informado inválido!");


            }
            else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("O raio deve ser maior que 0 (ZERO)");
                }

            }
        }
    }
}
