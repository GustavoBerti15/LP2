﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace Pestoque02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] entradas = new int[4, 4];
            int totalGeral = 0;

            
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    string texto = Interaction.InputBox(
                        "Digite a entrada do Produto " + (i + 1) + " - Semana " + (j + 1),
                        "Entrada de Dados");

                    int valor;

                    if (int.TryParse(texto, out valor) && valor >= 0)
                    {
                        entradas[i, j] = valor;
                    }
                    else
                    {
                        MessageBox.Show("Digite apenas números maiores ou iguais a zero.");
                        j--; 
                    }
                }
            }

            

            
            for (int i = 0; i < 4; i++)
            {
                int totalProduto = 0;
                lstResultado.Items.Add("Entradas do Produto " + (i + 1) + ":");

                for (int j = 0; j < 4; j++)
                {
                    lstResultado.Items.Add("  Semana " + (j + 1) + ": " + entradas[i, j]);
                    totalProduto += entradas[i, j];
                }

                lstResultado.Items.Add("Total do Produto " + (i + 1) + ": " + totalProduto);
               
                totalGeral += totalProduto;
            }

            lstResultado.Items.Add("Total Geral: " + totalGeral);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstResultado.Items.Clear();
        }
    }
}
